@SuppressWarnings("unchecked")
public class mysolution {
	static int solve(int N, char[] message, char[] presses) {
	    return -1;
	}
}
