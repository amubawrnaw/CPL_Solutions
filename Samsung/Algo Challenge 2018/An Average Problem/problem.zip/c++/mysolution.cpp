int solve(int N, int A[100000]) {
    return -1;
}