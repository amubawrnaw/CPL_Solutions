

/**
 * The inner class which will hold the your implemented APIs
 *
 */
class mysolution {
    // You may add your own variables here
    // You may add your own variables here
  
    

    // Implement your APIs here
    /**
	 * An API for initialization
     *
     */
    public void init() {
    	
    }


    public int addMember(int idNumber, String name, int headId, String  dateJoined, int points){
    
        return 0;
    }


    public int editMember(int idNumber, String name, int headId, int points) {
    
        return 0;
    }


    public int deleteMember(int idNumber) {
		
		return 0;
    }

    public int getTotalPoints(int idNumber) {
    
    	return -1;
    }
    
    public int search(int searchtype, String searchName) {

    	
    	return 0;
    }
    
 
}