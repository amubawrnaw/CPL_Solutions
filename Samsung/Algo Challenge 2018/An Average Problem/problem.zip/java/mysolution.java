public class mysolution {
	
	@SuppressWarnings("unchecked")
	public static int solve(int N, int[] A) {
		return -1;
	}
}
