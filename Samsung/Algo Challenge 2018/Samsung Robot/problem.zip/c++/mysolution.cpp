int solve(int N, char message[100001], char presses[400001]) {
    return -1;
}
