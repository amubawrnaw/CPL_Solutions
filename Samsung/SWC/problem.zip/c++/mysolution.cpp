void init() {

}

int addMember(int id_Number, char name[100], int head_id, char date_joined[100], int points) {
	return 0;
}

int editMember(int id_number, char name[100], int head_id, int points) {
	return 0;
}

int deleteMember(int id_number) {
	return 0;
}

int getTotalPoints(int id_number) {
	return 0;
}

int search(int search_type, char name[100]) {
	return 0;
}