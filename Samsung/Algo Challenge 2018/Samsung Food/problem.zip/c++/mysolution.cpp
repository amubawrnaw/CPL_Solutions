int solve(int N, int D[100000]) {
    return -1;
}