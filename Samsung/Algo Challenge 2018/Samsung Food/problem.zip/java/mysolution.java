
public class mysolution {
	@SuppressWarnings("unchecked")
	public static int solve(int N, int[] D) {
		   return 0;
		}
}
